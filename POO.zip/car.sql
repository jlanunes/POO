/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : car

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2021-09-24 07:30:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cars
-- ----------------------------
DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `placa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `renavam` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fabricante` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ano_fabricante` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ano_modelo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of cars
-- ----------------------------
INSERT INTO `cars` VALUES ('2', '987654321', 's2', '90025', 'Toyoda', '2017', '2017');
INSERT INTO `cars` VALUES ('45', '123456', '123abc', 'toyoda', 'toyoda', '1979', '1979');
INSERT INTO `cars` VALUES ('46', '123456789', '123456asdfgh', 'Nisan', 'Nisan', '1980', '1959');
