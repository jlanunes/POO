package com.application.carapp;

import static javafx.geometry.Pos.CENTER;

import java.awt.Desktop.Action;
import java.util.ArrayList;

import com.application.carapp.Car.OnEditButtonClickListener;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;



public class Main extends Application {
    private Stage stage;
    private CarManager manager;
    public Main() {

    }

    public static void main(String[] args) throws Exception {
        launch(args);
    }

    public void start(Stage stage) throws Exception {
        try {
        	
        	this.manager=new CarManager();
        	Car emptyCar=new Car();
        	showRegisterScene(stage,emptyCar);
        	
        	
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    private void showRegisterScene(Stage stage, final Car car) {
    	final Stage tempStage=stage;
    	HBox titleHBox = new HBox();
    	titleHBox.setMinWidth(500);
    	titleHBox.setMaxWidth(500);
    	titleHBox.setAlignment(CENTER);
    	titleHBox.setMinHeight(100);
    	Text titleText = new Text();
        Font font = Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 30);
        titleText.setFont(font);
        titleText.setText("Cadastro de Carro");
        titleHBox.getChildren().addAll(titleText);
   
    	HBox placaHBox = new HBox();
    	placaHBox.setMinWidth(500);
    	placaHBox.setMaxWidth(500);
    	placaHBox.setSpacing(0);
        Label placaLabel = new Label("Placa");
        placaLabel.setFont(new Font(18));
        final TextField placaText = new TextField();
        placaLabel.setMinWidth(placaHBox.getMinWidth() / 3);
        placaLabel.setMaxWidth(placaHBox.getMinWidth() / 3);
        placaText.setMinWidth(placaHBox.getMinWidth() / 2);
        placaText.setMaxWidth(placaHBox.getMinWidth() / 2);
        placaHBox.getChildren().addAll(placaLabel, placaText);
        placaText.setText(car.getPlaca());

    	HBox renavamHBox = new HBox();
    	renavamHBox.setMinWidth(500);
    	renavamHBox.setMaxWidth(500);
    	renavamHBox.setSpacing(0);
        Label renavamLabel = new Label("RENAVAM");
        renavamLabel.setFont(new Font(18));
        final TextField renavamText = new TextField();
        renavamLabel.setMinWidth(renavamHBox.getMinWidth() / 3);
        renavamLabel.setMaxWidth(renavamHBox.getMinWidth() / 3);
        renavamText.setMinWidth(renavamHBox.getMinWidth() / 2);
        renavamText.setMaxWidth(renavamHBox.getMinWidth() / 2);
        renavamHBox.getChildren().addAll(renavamLabel, renavamText);
        renavamText.setText(car.getRenavam());
        
    	HBox modeloHBox = new HBox();
    	modeloHBox.setMinWidth(500);
    	modeloHBox.setMaxWidth(500);
    	modeloHBox.setSpacing(0);
        Label modeloLabel = new Label("Modelo");
        modeloLabel.setFont(new Font(18));
        final TextField modeloText = new TextField();
        modeloLabel.setMinWidth(modeloHBox.getMinWidth() / 3);
        modeloLabel.setMaxWidth(modeloHBox.getMinWidth() / 3);
        modeloText.setMinWidth(modeloHBox.getMinWidth() / 2);
        modeloText.setMaxWidth(modeloHBox.getMinWidth() / 2);
        modeloHBox.getChildren().addAll(modeloLabel, modeloText);
        modeloText.setText(car.getModelo());
        
    	HBox fabricanteHBox = new HBox();
    	fabricanteHBox.setMinWidth(500);
    	fabricanteHBox.setMaxWidth(500);
    	fabricanteHBox.setSpacing(0);
        Label fabricanteLabel = new Label("Fabricante");
        fabricanteLabel.setFont(new Font(18));
        final TextField fabricanteText = new TextField();
        fabricanteLabel.setMinWidth(fabricanteHBox.getMinWidth() / 3);
        fabricanteLabel.setMaxWidth(fabricanteHBox.getMinWidth() / 3);
        fabricanteText.setMinWidth(fabricanteHBox.getMinWidth() / 2);
        fabricanteText.setMaxWidth(fabricanteHBox.getMinWidth() / 2);
        fabricanteHBox.getChildren().addAll(fabricanteLabel, fabricanteText);
        fabricanteText.setText(car.getFabricante());
        
    	HBox afabricanteHBox = new HBox();
    	afabricanteHBox.setMinWidth(500);
    	afabricanteHBox.setMaxWidth(500);
    	afabricanteHBox.setSpacing(0);
        Label afabricanteLabel = new Label("Ano de Fabrica��o");
        afabricanteLabel.setFont(new Font(18));
        final TextField afabricanteText = new TextField();
        afabricanteLabel.setMinWidth(afabricanteHBox.getMinWidth() / 3);
        afabricanteLabel.setMaxWidth(afabricanteHBox.getMinWidth() / 3);
        afabricanteText.setMinWidth(afabricanteHBox.getMinWidth() / 2);
        afabricanteText.setMaxWidth(afabricanteHBox.getMinWidth() / 2);
        afabricanteHBox.getChildren().addAll(afabricanteLabel, afabricanteText);
        afabricanteText.setText(car.getAnoFabricante());
        
    	HBox aModeloHBox = new HBox();
    	aModeloHBox.setMinWidth(500);
    	aModeloHBox.setMaxWidth(500);
    	aModeloHBox.setSpacing(0);
        Label aModeloLabel = new Label("Ano de Modelo");
        aModeloLabel.setFont(new Font(18));
        final TextField aModeloText = new TextField();
        aModeloLabel.setMinWidth(aModeloHBox.getMinWidth() / 3);
        aModeloLabel.setMaxWidth(aModeloHBox.getMinWidth() / 3);
        aModeloText.setMinWidth(aModeloHBox.getMinWidth() / 2);
        aModeloText.setMaxWidth(aModeloHBox.getMinWidth() / 2);
        aModeloHBox.getChildren().addAll(aModeloLabel, aModeloText);
        aModeloText.setText(car.getAnoModelo());
        
        HBox buttonHBox=new HBox();
        buttonHBox.setMinWidth(500);
        buttonHBox.setMaxWidth(500);
        buttonHBox.setSpacing(30);  
        buttonHBox.setMinHeight(50);
    	buttonHBox.setAlignment(Pos.BOTTOM_RIGHT);
    	 
        Button cadastroBtn = new Button("Cadastro");
        Button limparBtn = new Button("Limpar");
        Button viewCarsBtn=new Button("Ver Carros");
        cadastroBtn.setMaxWidth(100);
        cadastroBtn.setMinWidth(100);
        limparBtn.setMinWidth(100);
        limparBtn.setMaxWidth(100);
        viewCarsBtn.setMaxWidth(100);
        viewCarsBtn.setMinWidth(100);
        buttonHBox.getChildren().addAll(cadastroBtn, limparBtn, viewCarsBtn);
        
       
        cadastroBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	String placa=placaText.getText();
            	String renavam=renavamText.getText();
            	String modelo=modeloText.getText();
            	String fabricante=fabricanteText.getText();
            	String anoFabricante=afabricanteText.getText();
            	String anoModelo=aModeloText.getText();
            	int isValid=checkValidation(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
            	if(isValid==1) {
            		if(car.getId()==0) {
                        manager.registerNewCar(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
                	}else {
                		manager.updateCar(car.getId(), placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
                	}
                    infoBox("Successed", "Result", "");
                    showRegisteredTable(tempStage);
            	}            	
            }
        });
        limparBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	String placa=placaText.getText();
            	String renavam=renavamText.getText();
            	String modelo=modeloText.getText();
            	String fabricante=fabricanteText.getText();
            	String anoFabricante=afabricanteText.getText();
            	String anoModelo=aModeloText.getText();
            	
            	if(car.getId()==0) {
            		manager.deleteOldCar(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
            	}else {
            		manager.deleteOldCar(car.getId());
            	}
            	
                
                placaText.clear();
                renavamText.clear();
                modeloText.clear();
                fabricanteText.clear();
                afabricanteText.clear();
                aModeloText.clear();
                infoBox("Deleted", "Result", "");
                
            }
        });
        
        viewCarsBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                showRegisteredTable(tempStage);
            }
        });
        
        
        VBox root = new VBox();
        ObservableList list = root.getChildren();
        list.addAll(titleHBox, placaHBox, renavamHBox,modeloHBox, fabricanteHBox,afabricanteHBox,aModeloHBox, buttonHBox);
        
        
        root.setAlignment(CENTER);
        root.setSpacing(10);
        Scene scene = new Scene(root, 800, 500);
        stage.setTitle("Cadastro de Carro");
        stage.setScene(scene);
        stage.show();
    }
    
    
    private void showRegisteredTable(Stage stage) {
    	final Stage tempStage=stage;
    	//Label for education
    	HBox titleHBox = new HBox();
    	titleHBox.setMinWidth(500);
    	titleHBox.setMaxWidth(500);
    	titleHBox.setAlignment(CENTER);
    	titleHBox.setMinHeight(100);
    	Label label = new Label("Carros Cadastrados");
        Font font = Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 30);
        label.setFont(font);
        titleHBox.getChildren().addAll(label);
        
        //Creating a table view
        TableView<Car> table = new TableView<Car>();
        final ObservableList<Car> data = FXCollections.observableArrayList();
        ArrayList<Car> registeredCars=this.manager.getAllRegisteredCars();

		OnEditButtonClickListener onEditButtonClickListener=new OnEditButtonClickListener() {
			
			@Override
			public void onEditButtonClicked(int id, String placa, String renavam, String modelo, String fabricante,
					String anoFabricante, String anoModelo) {
					Car readCar=new Car(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
					readCar.setId(id);
					showRegisterScene(tempStage, readCar);
				
			}
		};
        for(int i=0;i<registeredCars.size();i++) {
        	registeredCars.get(i).setOnEditButtonClickListener(onEditButtonClickListener);
        	data.add(registeredCars.get(i));
        }
        //Creating columns
        TableColumn placaCol = new TableColumn("Placa");
        placaCol.setCellValueFactory(new PropertyValueFactory<>("placa"));
        TableColumn modeloCol = new TableColumn("Modelo");
        modeloCol.setCellValueFactory(new PropertyValueFactory("modelo"));
        TableColumn fabricanteCol = new TableColumn("Fabricante");
        fabricanteCol.setCellValueFactory(new PropertyValueFactory("fabricante"));
        TableColumn anoFabricanteCol = new TableColumn("Ano de Fabricante");
        anoFabricanteCol.setCellValueFactory(new PropertyValueFactory("anoFabricante"));
        TableColumn actionCol = new TableColumn("Action");
        actionCol.setCellValueFactory(new PropertyValueFactory<>("editButtonProp"));
        
        placaCol.setPrefWidth(150);
        modeloCol.setPrefWidth(150);
        fabricanteCol.setPrefWidth(150);
        anoFabricanteCol.setPrefWidth(150);
        actionCol.setPrefWidth(80);
        ObservableList<String> list = FXCollections.observableArrayList();
        table.setItems(data);
        table.getColumns().addAll(placaCol, modeloCol, fabricanteCol, anoFabricanteCol, actionCol);
        table.setMaxSize(750, 450);
        
        Button register=new Button("Registro");
        register.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				Car tempCar=new Car();
				showRegisterScene(tempStage, tempCar);
				
			}
        	
        });
        
        
        VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 50, 50, 60));
        vbox.getChildren().addAll(titleHBox, table, register);
        vbox.setAlignment(CENTER);
        //Setting the scene
        Scene scene = new Scene(vbox, 800, 500);
        stage.setTitle("Table View Exmple");
        stage.setScene(scene);
        stage.show();
    }
    
    private void infoBox(String infoMessage, String titleBar, String headerMessage)
    {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(titleBar);
        alert.setHeaderText(headerMessage);
        alert.setContentText(infoMessage);
        alert.showAndWait();
    }
    
    private int checkValidation(String placa, String renavam, String modelo, String fabricante,String anoFabricante, String anoModelo) {
    	int result=0;
    	if(placa.equals("")||renavam.equals("")||modelo.equals("")||fabricante.equals("")||anoFabricante.equals("")||anoModelo.equals("")) {
    		result=0;
    		infoBox("Please fill correctly...", "Input Error","Error");
    		return result;
    	}else
    		result=1;
    	return result;
    	
    }
}
