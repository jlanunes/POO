package com.application.carapp;

import java.util.ArrayList;

import javafx.beans.property.StringProperty;

public class CarManager {
	private DbHelper dbHelper;
	public CarManager() {
		this.dbHelper=new DbHelper();
	}
	
	public void registerNewCar(String placa, String renavam, String modelo, String fabricante,String anoFabricante, String anoModelo ) {
		Car newCar=new Car(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
		this.dbHelper.insertNewCar(newCar);
	}

	public void updateCar(int id,String placa, String renavam, String modelo, String fabricante,String anoFabricante, String anoModelo ) {
		Car newCar=new Car(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
		this.dbHelper.updateCar(newCar, id);
	}

	public void deleteOldCar(String placa, String renavam, String modelo, String fabricante,String anoFabricante, String anoModelo ) {
		Car newCar=new Car(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
		this.dbHelper.deleteOldCar(newCar);
	}
	
	public void deleteOldCar(int id) {
		this.dbHelper.deleteOldCar(id);
	}
	
	public ArrayList<Car> getAllRegisteredCars() {
		ArrayList<Car> registeredCars=dbHelper.getAllCars();
		return registeredCars;
	}
	
	

}
