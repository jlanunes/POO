package com.application.carapp;


import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;

public class DbHelper {
	
	 // init database constants
    private static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/car?useSSL=false&serverTimezone=UTC&useLegacyDatetimeCode=false";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    
    // init connection object
    private Connection connection;
    // init properties object
    private Properties properties;


    public DbHelper() {
    }
    // create properties
    private Properties getProperties() {
        if (properties == null) {
            properties = new Properties();
            properties.setProperty("user", USERNAME);
            properties.setProperty("password", PASSWORD);
        }
        return properties;
    }

    // connect database
    public Connection connect() {
        if (connection == null) {
            try {
                Class.forName(DATABASE_DRIVER);
                connection = DriverManager.getConnection(DATABASE_URL, getProperties());
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    // disconnect database
    public void disconnect() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	
    

    public void insertNewCar(Car newCar){
    	connect();
        String sqlQuery = "INSERT INTO `cars`(placa, renavam, modelo, fabricante, ano_fabricante, ano_modelo) "
        		+ "VALUES ('" + newCar.getPlaca() + "', '" + newCar.getRenavam() +  "', '" + newCar.getModelo()+ "', '" + newCar.getFabricante() +  "', '" + newCar.getAnoFabricante() + "', '" + newCar.getAnoModelo() + "'"+");";
        try {
            boolean resultSet = this.connection.createStatement().execute(sqlQuery);
            disconnect();
        } catch (SQLException throwables) {
            disconnect();
            throwables.printStackTrace();
        }
    }
    
    public void updateCar(Car newCar, int id) {
    	connect();
        String sqlQuery = "UPDATE cars SET placa='"+newCar.getPlaca()+"',renavam='"+newCar.getRenavam()+
        		"',modelo='"+newCar.getModelo()+"', fabricante='"+newCar.getFabricante()+"', ano_fabricante='"+newCar.getAnoFabricante()+
        		"',ano_modelo='"+newCar.getAnoModelo()+"' WHERE id='"+id+"'";
        try {
            boolean resultSet = this.connection.createStatement().execute(sqlQuery);
            disconnect();
        } catch (SQLException throwables) {
            disconnect();
            throwables.printStackTrace();
        }
    }
    
    public void deleteOldCar(Car oldCar) {
    	connect();
        String sqlQuery = "Delete from cars where placa='"+oldCar.getPlaca()+"'"+"and renavam='"+oldCar.getRenavam()+"'";
        try {
            boolean resultSet = this.connection.createStatement().execute(sqlQuery);
            disconnect();
        } catch (SQLException throwables) {
            disconnect();
            throwables.printStackTrace();
        }
    }
    
    public void deleteOldCar(int id) {
    	connect();
        String sqlQuery = "Delete from cars where id='"+id+"'";
        try {
            boolean resultSet = this.connection.createStatement().execute(sqlQuery);
            disconnect();
        } catch (SQLException throwables) {
            disconnect();
            throwables.printStackTrace();
        }
    }

    public ArrayList<Car> getAllCars() {
    	connect();
        ArrayList<Car> cars = new ArrayList<>();
        String sqlQuery = "SELECT * FROM cars";
        try {
            ResultSet rs = connection.createStatement().executeQuery(sqlQuery);
            while (rs.next()) {
            	int id=rs.getInt("id");
                String placa = rs.getString("placa");
                String renavam = rs.getString("renavam");
                String modelo = rs.getString("modelo");
                String fabricante = rs.getString("fabricante");
                String anoFabricante = rs.getString("ano_fabricante");
                String anoModelo = rs.getString("ano_modelo");
                
                Car tempCar=new Car(placa, renavam, modelo, fabricante, anoFabricante, anoModelo);
                tempCar.setId(id);
                cars.add(tempCar);
            }

            disconnect();
            return cars;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            disconnect();
            return null;
        }
    }

}
