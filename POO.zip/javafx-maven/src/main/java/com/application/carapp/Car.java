package com.application.carapp;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.ObjectProperty;

public class Car {
	private StringProperty placa;
	private StringProperty renavam;
	private StringProperty modelo;
	private StringProperty fabricante;
	private StringProperty anoFabricante;
	private StringProperty anoModelo;

    private SimpleObjectProperty<Button> editButtonProp;
    private OnEditButtonClickListener onEditButtonClickListener;
    private int id;
	
	
	public Car() {
		this.placa=new SimpleStringProperty("");
		this.renavam = new SimpleStringProperty("");
		this.modelo = new SimpleStringProperty("");
		this.fabricante = new SimpleStringProperty("");
		this.anoFabricante = new SimpleStringProperty("");
		this.anoModelo = new SimpleStringProperty("");
		initButton();
		this.id=0;
	}
	
	public Car(StringProperty placa, StringProperty renavam, StringProperty modelo, StringProperty fabricante,
			StringProperty anoFabricante, StringProperty anoModelo) {
		super();
		this.placa = placa;
		this.renavam = renavam;
		this.modelo = modelo;
		this.fabricante = fabricante;
		this.anoFabricante = anoFabricante;
		this.anoModelo = anoModelo;
		initButton();
		this.id=0;
		
	}
	
	public Car(String placa2, String renavam2, String modelo2, String fabricante2, String anoFabricante2,
			String anoModelo2) {

		this.placa=new SimpleStringProperty(placa2);
		this.renavam=new SimpleStringProperty(renavam2);
		this.modelo=new SimpleStringProperty(modelo2);
		this.fabricante=new SimpleStringProperty(fabricante2);
		this.anoFabricante=new SimpleStringProperty(anoFabricante2);
		this.anoModelo=new SimpleStringProperty(anoModelo2);
		initButton();
		this.id=0;
	}

	private void initButton() {
		Button editButton=new Button("Edit");
		editButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	onEditButtonClickListener.onEditButtonClicked(id, placa.get(), renavam.get(), modelo.get(),
            			fabricante.get(), anoFabricante.get(), anoModelo.get());
            }
		});
		editButtonProp=new SimpleObjectProperty(editButton);
	}
	
	public String getPlaca() {
		return placa.get();
	}
	public void setPlaca(StringProperty placa) {
		this.placa = placa;
	}
	public String getRenavam() {
		return renavam.get();
	}
	public void setRenavam(StringProperty renavam) {
		this.renavam = renavam;
	}
	public String getModelo() {
		return modelo.get();
	}
	public void setModelo(StringProperty modelo) {
		this.modelo = modelo;
	}
	public String getFabricante() {
		return fabricante.get();
	}
	public void setFabricante(StringProperty fabricante) {
		this.fabricante = fabricante;
	}
	public String getAnoFabricante() {
		return anoFabricante.get();
	}
	public void setAnoFabricante(StringProperty anoFabricante) {
		this.anoFabricante = anoFabricante;
	}
	public String getAnoModelo() {
		return anoModelo.get();
	}
	public void setAnoModelo(StringProperty anoModelo) {
		this.anoModelo = anoModelo;		
	}
	
	public void setId(int id) {
		this.id=id;
	}
	public int getId() {
		return this.id;
	}
	
	public ObjectProperty<Button> editButtonPropProperty() {
        return editButtonProp;
    }
	
	public interface OnEditButtonClickListener{
		void onEditButtonClicked(int id, String placa, String renavam, String modelo, String fabricante,String anoFabricante, String anoModelo );
	}
	public void setOnEditButtonClickListener(OnEditButtonClickListener onEditButtonClickListener) {
		this.onEditButtonClickListener=onEditButtonClickListener;
	}
	

}
