package src.test;

import com.application.gamehelper.controller.Manager;
import com.application.gamehelper.model.Event;
import com.application.gamehelper.model.Player;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

//@RunWith(MockitoJUnitRunner.class)
public class UnitTest {
    Player player;
    Event event;
    Manager manager = new Manager();
    //ObservableList<Player> playerList= FXCollections.observableArrayList();

//    @Mock
//    private ObservableList<Player> playerList;
//    @Mock
//    private Event event;
//    @InjectMocks
//    Manager manager = new Manager();


    @Before
    public void init() {
        this.event = new Event();
        this.event.setEventName("eee");
        this.manager.setEvent(event);
    }

    /**
     * Test for AddPlayerToEvent method      *
     **/

    // Test for adding player with tank role to the event.
    @Test
    public void testAddPlayerToEventWithTankRole1() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 1 player with tank role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        assertEquals(0, result);
    }
    // Test for adding player with tank role to the event.
    @Test
    public void testAddPlayerToEventWithTankRole2() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 2 players with tank role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        assertEquals(0, result);
    }
    // Test for adding player with tank role to the event.
    @Test
    public void testAddPlayerToEventWithTankRole3() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 3 players with tank role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        assertEquals(1, result);
    }

    // Test for adding player with heal role to the event.
    @Test
    public void testAddPlayerToEventWithHealRole1() {
        // add player to player list.
        this.player = new Player("AAA", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 1 player with heal role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        assertEquals(0, result);
    }
    // Test for adding player with heal role to the event.
    @Test
    public void testAddPlayerToEventWithHealRole2() {
        // add player to player list.
        this.player = new Player("AAA", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 4 players with heal role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        assertEquals(0, result);
    }
    // Test for adding player with heal role to the event.
    @Test
    public void testAddPlayerToEventWithHealRole3() {
        // add player to player list.
        this.player = new Player("AAA", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 3 players with heal role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        assertEquals(2, result);
    }

    // Test for adding player with dps role to the event.
    @Test
    public void testAddPlayerToEventWithDpsRole1() {
        // add player to player list.
        this.player = new Player("AAA", "dps", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 3 players with dps role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        assertEquals(0, result);
    }

    // Test for adding player with dps role to the event.
    @Test
    public void testAddPlayerToEventWithDpsRole2() {
        // add player to player list.
        this.player = new Player("AAA", "dps", "Warrior");
        this.manager.addPlayer(this.player);
        this.manager.addPlayer(this.player);

        // when adding 15 players with dps role, it should return 0.
        int result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        result = this.manager.addPlayerToEvent(1);
        assertEquals(3, result);
    }

    /**
     * Test for SetRoleNumbers method.
     */

    // Test for checking role numbers after adding players to event.
    @Test
    public void TestSetRoleNumbers1() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("BBB", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("CCC", "dps", "Warrior");
        this.manager.addPlayer(this.player);

        // add players with tank role
        this.manager.addPlayerToEvent(0);
        // add players with heal role
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        // add players with dps role
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        // reset role numbers of the event
        manager.setRoleNumbers(manager.getEvent());

        int tankRoleNo = manager.getTankPlayerNo();
        assertEquals(1, tankRoleNo);
        int healRoleNo = manager.getHealPlayerNo();
        assertEquals(3, healRoleNo);
        int dpsRoleNo = manager.getDpsPlayerNo();
        assertEquals(6, dpsRoleNo);
    }

    // Test for checking role numbers after adding players to event()
    // when add 3 times tank role player , 6 times heal role player.
    // but it should return 2 for tank role player, 4 for heal role player.
    @Test
    public void TestSetRoleNumbers2() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("BBB", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("CCC", "dps", "Warrior");
        this.manager.addPlayer(this.player);

        // add players with tank role
        this.manager.addPlayerToEvent(0);
        this.manager.addPlayerToEvent(0);
        this.manager.addPlayerToEvent(0);
        // add players with heal role
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        // add players with dps role
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        // reset role numbers of the event
        manager.setRoleNumbers(manager.getEvent());

        int tankRoleNo = manager.getTankPlayerNo();
        assertEquals(2, tankRoleNo);
        int healRoleNo = manager.getHealPlayerNo();
        assertEquals(4, healRoleNo);
        int dpsRoleNo = manager.getDpsPlayerNo();
        assertEquals(6, dpsRoleNo);
    }

    // Test for checking role numbers after adding only players with dps role to event().
    @Test
    public void TestSetRoleNumbers3() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("BBB", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("CCC", "dps", "Warrior");
        this.manager.addPlayer(this.player);

        // add players with dps role
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        // reset role numbers of the event
        manager.setRoleNumbers(manager.getEvent());

        int tankRoleNo = manager.getTankPlayerNo();
        assertEquals(0, tankRoleNo);
        int healRoleNo = manager.getHealPlayerNo();
        assertEquals(0, healRoleNo);
        int dpsRoleNo = manager.getDpsPlayerNo();
        assertEquals(6, dpsRoleNo);
    }

    /**
     * Test for removePlayerFromEvent method
     */
    @Test
    public void testRemovePlayerFromEvent() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("BBB", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("CCC", "dps", "Warrior");
        this.manager.addPlayer(this.player);
        // add players with tank role
        this.manager.addPlayerToEvent(0);
        this.manager.addPlayerToEvent(0);
        // add players with heal role
        this.manager.addPlayerToEvent(1);
        // add players with dps role
        this.manager.addPlayerToEvent(2);
        // remove player with heal role from event
        manager.removePlayerFromEvent(1);
        // reset role numbers of the event
        manager.setRoleNumbers(manager.getEvent());

        int tankRoleNo = manager.getTankPlayerNo();
        assertEquals(2, tankRoleNo);
        int healRoleNo = manager.getHealPlayerNo();
        assertEquals(0, healRoleNo);
        int dpsRoleNo = manager.getDpsPlayerNo();
        assertEquals(1, dpsRoleNo);
    }
    /**
     * Test for validateSubmit method
     */

    // Test for validation method when add 20 players to event.
    // it should return 0;
    @Test
    public void testValidateSubmit1() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("BBB", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("CCC", "dps", "Warrior");
        this.manager.addPlayer(this.player);
        // add players with tank role
        this.manager.addPlayerToEvent(0);
        this.manager.addPlayerToEvent(0);
        // add players with heal role
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        // add players with dps role
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);

        int result = manager.validateSubmit(manager.getEvent());
        assertEquals(0, result);
    }
    // Test for validation method when add less than 20 players to event.
    // it should return 1;
    @Test
    public void testValidateSubmit2() {
        // add player to player list.
        this.player = new Player("AAA", "tank", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("BBB", "heal", "Warrior");
        this.manager.addPlayer(this.player);
        this.player = new Player("CCC", "dps", "Warrior");
        this.manager.addPlayer(this.player);
        // add players with tank role
        this.manager.addPlayerToEvent(0);
        this.manager.addPlayerToEvent(0);
        // add players with heal role
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        this.manager.addPlayerToEvent(1);
        // add players with dps role
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);
        this.manager.addPlayerToEvent(2);

        int result = manager.validateSubmit(manager.getEvent());
        assertEquals(1, result);
    }

}
