Crie o banco de dados "car" e execute o arquivo sql, então ele criará a tabela "cars" no banco de dados "caro".
Execute o projeto.

Uso o Navicate para mysql manager.